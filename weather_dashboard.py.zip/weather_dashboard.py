# weather_dashboard.py
import streamlit as st
import requests

API_KEY = "d401cf447d70a0465b96be1cb0cc4e43"  # Replace this with your actual API key

def get_weather(city):
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        weather = {
            "City": data["name"],
            "Temperature (°C)": data["main"]["temp"],
            "Humidity (%)": data["main"]["humidity"],
            "Weather": data["weather"][0]["description"].title(),
            "Wind Speed (m/s)": data["wind"]["speed"]
        }
        return weather
    else:
        return None

st.title("🌤️ Live Weather Dashboard")
city = st.text_input("Enter city name")

if city:
    weather = get_weather(city)
    if weather:
        for key, value in weather.items():
            st.write(f"**{key}**: {value}")
    else:
        st.error("❌ City not found or API error.")
